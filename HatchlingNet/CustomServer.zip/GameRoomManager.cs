﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomServer
{
    class GameRoomManager
    {
        List<GameRoom> roomList;

        public GameRoomManager()
        {
            this.roomList = new List<GameRoom>();
        }

        public void CreateRoom()
        {

        }

        public void EnterRoom()
        {

        }

        public void RemoveRoom()
        {

        }
    }
}
