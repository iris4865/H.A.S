﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HatchlingNet
{
    class Define
    {
        public static readonly Int16 HEADERSIZE = 2;
        public static readonly Int16 PROTOCOLSIZE = 2;

    }
}
