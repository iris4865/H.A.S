﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HatchlingNet
{
    public struct MyVector3
    {
        public float x;
        public float y;
        public float z;
    }
}
