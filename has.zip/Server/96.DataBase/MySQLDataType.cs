﻿namespace MySqlDataBase
{
    public enum MySQLDataType
    {
        INT,
        CHAR,
        VARCHAR
    }
}
